import { sqliteTable, text, integer, uniqueIndex } from 'drizzle-orm/sqlite-core';
export const settings = sqliteTable('settings', { id: text('id').primaryKey(), value: text('value').notNull() });
export const bookings = sqliteTable('bookings', {
 token: text('token').primaryKey(), slot: text('slot').notNull(), personHash: text('person_hash').notNull(), payload: text('payload').notNull(), created: text('created').notNull(), checked: text('checked'), sequence: integer('sequence'),
}, t=>[uniqueIndex('one_person_per_slot').on(t.slot,t.personHash),uniqueIndex('one_sequence_per_slot').on(t.slot,t.sequence)]);
export const attempts = sqliteTable('attempts', { id:text('id').primaryKey(), count:integer('count').notNull(), expires:integer('expires').notNull() });
