import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata={title:'中原歌剧周 · 预约入场',description:'选择场次、填写信息、领取电子入场凭证。',robots:{index:false,follow:false},referrer:'no-referrer'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body>{children}</body></html>}
