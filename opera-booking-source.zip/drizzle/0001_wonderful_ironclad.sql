ALTER TABLE `bookings` ADD `sequence` integer;--> statement-breakpoint
CREATE UNIQUE INDEX `one_sequence_per_slot` ON `bookings` (`slot`,`sequence`);