CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `bookings` (
	`token` text PRIMARY KEY NOT NULL,
	`slot` text NOT NULL,
	`person_hash` text NOT NULL,
	`payload` text NOT NULL,
	`created` text NOT NULL,
	`checked` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `one_person_per_slot` ON `bookings` (`slot`,`person_hash`);--> statement-breakpoint
CREATE TABLE `settings` (
	`id` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
