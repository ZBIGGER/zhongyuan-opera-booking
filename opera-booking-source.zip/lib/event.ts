export const defaultConfig = { title:'中原歌剧周', location:'河南艺术中心', date:'2026年10月11日—12日', program:'《贾尼斯基基》《乡村骑士》', organizer:'中原歌剧周活动主办方', open:true, slots:[{id:'am',name:'10月11日场',date:'2026年10月11日',time:'18:00',capacity:450},{id:'pm',name:'10月12日场',date:'2026年10月12日',time:'18:00',capacity:450}] };
export type EventConfig = typeof defaultConfig;
